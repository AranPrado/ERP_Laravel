<?php $__env->startSection('title', 'Carrinho de Compras'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row mt-4">
    <div class="col-12 col-md-12">
      <div class="card">
        <div class="card-header border-0 bg-transparent">
          <h4>Meu carrinho</h4>
        </div>
        <div class="card-body">
          <table class="table table-stripe">
            <thead>
              <tr>
                <th scope="row">#</th>
                <th>Cliente</th>
                <th>Valor</th>
                <th>Data/Hora</th>
            </tr>
            </thead>
            <tbody>
              <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($c['id']); ?></th>
                <td><?php echo e($c['name']); ?></td>
                <td><strong>R$ <?php echo e(number_format($c['price'], 2, ',', '.')); ?></strong></td>
                <td><?php echo e(date('d/m/Y - H:i', strtotime($c['created_at']))); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            
            </tbody>
            <tfoot>
              <tr>
                <td class="text-center" colspan="5">
                  <button class="btn btn-primary"> <i class="fa fa-check"></i> Solicitar</button>
                  <button type="reset" id="clearCart" class="btn btn-secondary"> <i class="fa fa-times"></i> Limpar carrinho</button>
                </td>
              </tr>
            </tfoot>
          </table>

        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script>
    document.querySelector('#clearCart').addEventListener('click', function(){
      fetch('<?php echo e(route("products.clearToCart")); ?>',{
        method: 'POST',
        headers: {'Content-Type': 'application/json',
        'x-csrf-token': '<?php echo e(csrf_token()); ?>'
      },
      body: JSON.stringify(
        {
          cart: 'cart'
        }
      )
      })
        .then(data => data.json())
        .then(res => {
          location.reload();
        })
        
    })
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views/erp/cart/index.blade.php ENDPATH**/ ?>