<?php $__env->startSection('title', 'Produtos'); ?>


<?php $__env->startSection('content'); ?>
  <form action="<?php echo e(route('products.create')); ?>" method="POST">
  <div class="row mt-4 d-flex justify-content-center">


    <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

    <?php if(Auth::user()->is_admin): ?>
    <div class="col-4">
      <div class="card">
        <div class="card-header">
          <h4>Cadastrar Produto</h4>
        </div>
        <div class="card-body">
          <?php echo csrf_field(); ?>

          <div class="mb-3">
            <label for="name">Nome</label>
            <input class="form-control" type="text" name="name" id="name" placeholder="Digite o nome" required autofocus autocomplete="off" value="<?php echo e(old('name')); ?>">
          </div>

          <div class="mb-3">
            <label for="">Quantidade</label>
            <input min="0" type="number" placeholder="Digite a quantidade" class="form-control" name='quantity' id="quantity" required autofocos value="<?php echo e(old('quantity')); ?>"/>   
          </div>

          <div class="mb-3">
            <label for="">Preço</label>
            <input min="0"  type="number" placeholder="Digite o preço" class="form-control" name='price' id="price" step="0.1" required autofocos value="<?php echo e(old('price')); ?>"/>   
        </div>


          <div class="mb-3 text-center">
              <button class="btn btn-primary"> <i class="fa fa-user-plus"></i> Criar</button>
              <button type="reset" class="btn btn-secondary"> <i class="fa fa-times"></i> Cancelar</button>
          </div>


        </div>
      </div>
    </div>
    
    <div class="col-4">
      <div class="card">
        <div class="card-header">
          <h4>Lista de Matéria Prima</h4>
        </div>
        <div class="card-body">
        <ul>
          <?php if($feedstocks->count() > 0): ?>
            <?php $__currentLoopData = $feedstocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedstock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
            <label>
              <input type="checkbox" name="feedstocks[]" value="<?php echo e($feedstock->name); ?>" /> 
              <span><?php echo e($feedstock->name); ?></span>
            </label>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <ul>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <div class="col-12 mt-4">
      <div class="card col-12">
        <div class="card-header">
          <h4>Produtos cadastrados</h4>
        </div>
        <div class="card-body">
          <?php echo csrf_field(); ?>

          <table id="feedstockTable" class="table table-stripe">
            <thead>
                <tr>
                    <th scope="row">ID</th>
                    <th>Name</th>
                    <th>Quantidade</th>
                    <th>Mat. Prima</th>
                    <th>Preço</th>
                    <th>Ação</th>
                </tr>
            </thead>

            
            <tbody>
                <?php if($products->count() > 0): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($product->id); ?></th>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td>...</td>
                        <td>R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
                        <td>
                          <?php if(Auth::user()->is_admin): ?>
                            <a onclick="edit('<?php echo e($product->id); ?>')" href="#">
                                <i class="fa fa-pen"></i>
                                Editar
                            </a>

                            <?php else: ?>

                            <a onclick="addCart('<?php echo e($product); ?>')" href="#">
                              <i class="fa fa-shopping-cart"></i>
                              Adicionar
                          </a>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>   
            </tbody>
            

        </table>


        </div>
      </div>
    </div>
  </div>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script>

    let addCart = (product) => {
      fetch('<?php echo e(route("products.addToCart")); ?>',{
        method: 'POST',
        headers: {'Content-Type': 'application/json',
        'x-csrf-token': '<?php echo e(csrf_token()); ?>'
      },
      body:product
      })
        .then(data => data.json())
        .then(res => 
          console.log(res)
        )
    }

  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views/erp/product/index.blade.php ENDPATH**/ ?>