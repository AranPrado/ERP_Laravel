<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-4">
  <div class="col-12">
    <div class="card shadow">
          <div class="card-header border-0 bg-trasparent d-flex justify-content-between">
              <h4>Lista de usuários</h4>
              <?php if(Auth::user()->is_admin): ?>
              <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
                <i class="fa fa-user-plus"></i>
                Cadastrar Novo Usuário
              </a>
              <?php endif; ?>
          </div>
          <div class="card-body">
    <nav>
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <button class="nav-link active" id="nav-client-tab" data-bs-toggle="tab" data-bs-target="#nav-client" type="button" role="tab" aria-controls="nav-client" aria-selected="true">Cliente</button>
        <?php if(Auth::user()->is_admin): ?>
        <button class="nav-link" id="nav-admin-tab" data-bs-toggle="tab" data-bs-target="#nav-admin" type="button" role="tab" aria-controls="nav-admin" aria-selected="false">Administradores</button>
        <?php endif; ?>
      </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade show active" id="nav-client" role="tabpanel" aria-labelledby="nav-client-tab">
        
            <table class="table table-stripe">
              <thead>
                <tr>
                  <th scope="row">ID</th>
                  <th>Nome Completo</th>
                  <th>Email</th>
                  <th>Data/Hora</th>
                  <?php if(Auth::user()->is_admin): ?>
                  <th>Ação</th>
                  <?php endif; ?>
                </tr>
              </thead>
              <tbody>

                <?php if($clients->count() > 0): ?>
                  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($client->id); ?></th>
                      <td><?php echo e($client->name); ?></td>
                      <td><?php echo e($client->email); ?></td>
                      <td><?php echo e(date('d/m/Y - H:i', strtotime($client->created_at))); ?></td>
                      <td>
                        <?php if(Auth::user()->is_admin): ?>
                        <a href="<?php echo e(route('users.edit', ['id' => $client->id])); ?>"><i class="fa fa-pen"></i> Editar</a> &nbsp; | &nbsp;
                        <a href="#" onclick="deleteProfile('<?php echo e($client->id); ?>')"><i class="fa fa-eye"></i> Deletar</a>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
              </tbody>
            </table>
          
      </div>
      <?php if(Auth::user()->is_admin): ?>
      <div class="tab-pane fade" id="nav-admin" role="tabpanel" aria-labelledby="nav-admin-tab">

        <table class="table table-stripe">
          <thead>
            <tr>
              <th scope="row">#</th>
              <th>Nome Completo</th>
              <th>Email</th>
              <th>Data/Hora</th>
              <th>Ação</th>
            </tr>
          </thead>
          <tbody>

            <?php if($admins->count() > 0): ?>
              <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($admin->id); ?></th>
                  <td><?php echo e($admin->name); ?></td>
                  <td><?php echo e($admin->email); ?></td>
                  
                  <td><?php echo e(date('d/m/Y - H:i', strtotime($admin->created_at))); ?></td>
                  
                  <td>
                    <a href="<?php echo e(route('users.edit', ['id' => $admin->id])); ?>"><i class="fa fa-pen"></i> Editar</a> &nbsp; | &nbsp;
                    <a href="#" onclick="deleteProfile('<?php echo e($admin->id); ?>')"><i class="fa fa-trash"></i> Deletar</a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div> 
      
      </div>
    </div> 
    
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    function deleteProfile(id) {
      Swal.fire({
        title: 'Tem certeza?',
        text: "Você está prestes a deleta uma conta de usuário!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#0d6efd',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sim, deletar!'
      }).then((result) => {
        if (result.isConfirmed) {

          fetch(`/users/delete/${id}`)
            .then(data => data.json())
            .then(res => {
              if(res.code === 200) {
                Swal.fire(
                  'Deletado!',
                  'O perfil foi deletado com sucesso.',
                  'success'
                ).then(function() {
                  location.reload();
                })
              } else {
                Swal.fire(
                  'Falha!',
                  'Não foi possível deltar o perfil.',
                  'error'
                )
              }
            });

          
        }
      })
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views\erp\users\index.blade.php ENDPATH**/ ?>