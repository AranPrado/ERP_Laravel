<?php $__env->startSection('title', 'Recuperar Senha'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row vh-100 align-items-center justify-content-center">
    <div class="col-4">
      <div class="card shadow-lg">
        <div class="card-header pt-5 bg-transparent border-0">
          <h2 class="text-primary text-center">Recuperar Senha</h2>
        </div>
        <div class="card-body">
          <?php if(session('status')): ?>
            <div class="alert alert-info">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
          <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="email">E-mail</label>
              <input class="form-control" type="email" name="email" id="email" autofocus autocomplete="off" required="" value="<?php echo e(old('email')); ?>" placeholder="usuario@exemplo.com" />
            </div>
            <div class="mb-3">
              <button class="btn btn-primary form-control">
              <i class="fas fa-envelope"></i> Enviar email
            </button>
            </div>
            <div class="mb-3">
              <a class="btn btn-lightform-control" href="<?php echo e(route('login')); ?>">
                <i class="fas fa-arrow-left"></i>
                Voltar ao login</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>