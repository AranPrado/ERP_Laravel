<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name', 'Laravel')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
          <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('dashboard')); ?>">Início</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(route('products.index')); ?>">Produtos</a>
              </li>
              <?php if(Auth::user()->is_admin): ?>
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(route('users.index')); ?>">Usuários</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(route('finance.index')); ?>">Financeiro</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo e(route('feedstock.index')); ?>">Materia Prima</a>
              </li>
              <?php endif; ?>

              <?php if(!Auth::user()->is_amdin): ?>
                <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="<?php echo e(route('cart')); ?>">
                    <i class="fa fa-shopping-cart"></i>
                  </a>
                </li>
              <?php endif; ?>

              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                 <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Perfil</a></li>
                  <li><a class="dropdown-item" href="#">Sobre</a></li>
                  <li><hr class="dropdown-divider"/></li>
                  
                  <li>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                      <a class="dropdown-item text-danger" href="route('logout')"
                         onclick="event.preventDefault();
                                                this.closest('form').submit();">
                        <?php echo e(__('Sair')); ?>

                      </a>
                    </form>
                    
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>

    <div class="container bg-light">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views/layouts/base.blade.php ENDPATH**/ ?>