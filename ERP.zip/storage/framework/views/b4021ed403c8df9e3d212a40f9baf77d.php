<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-4 mb-4">

    <div class="col-12 col-md-4">
        <div class="card shadow">
            <div class="card-body">
                <div class="d-flex">
                    <div class="col-4 d-flex flex-column justify-content-center align-items-center">
                        <i class="fas fa-users fa-3x text-secondary"></i>
                        <span class="h3 text-secondary">Clientes</span>
                    </div>
                    <div class="col-8 d-flex justify-content-end align-items-center">
                        <span class="h1 fw-bold text-primary"><?php echo e($clients->count()); ?></span>
                    </div>
                </div>
            </div>
            <div class="card-footer text-end border-0">
                <a href="<?php echo e(route('users.index')); ?>">Ver todos <i class="fa fa-arrow-right"></i> </a>
            </div>
        </div>
    </div>


    <?php if(Auth::user()->is_admin): ?>
    <div class="col-12 col-md-4">
        <div class="card shadow">
            <div class="card-body">
                <div class="d-flex">
                    <div class="col-4 d-flex flex-column justify-content-center align-items-center">
                        <i class="fas fa-user fa-3x text-secondary"></i>
                        <span class="h3 text-secondary">Admins</span>
                    </div>
                    <div class="col-8 d-flex justify-content-end align-items-center">
                        <span class="h1 fw-bold text-primary"><?php echo e($admins->count()); ?></span>
                    </div>
                </div>
            </div>
            <div class="card-footer text-end border-0">
                <a href="<?php echo e(route('users.index')); ?>">Ver todos <i class="fa fa-arrow-right"></i> </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="col-12 col-md-4">
        <div class="card shadow">
            <div class="card-body">
                <div class="d-flex">
                    <div class="col-4 d-flex flex-column justify-content-center align-items-center">
                        <i class="fas fa-box fa-3x text-secondary"></i>
                        <span class="h3 text-secondary">Produtos</span>
                    </div>
                    <div class="col-8 d-flex justify-content-end align-items-center">
                        <span class="h1 fw-bold text-primary"><?php echo e($products->count()); ?></span>
                    </div>
                </div>
            </div>
            <div class="card-footer text-end border-0">
                <a href="<?php echo e(route('products.index')); ?>">Ver todos <i class="fa fa-arrow-right"></i> </a>
            </div>
        </div>
    </div>

</div>


<div class="row">
    <?php if(Auth::user()->is_admin): ?>
        <div class="col-12 col-md-6">
            <div class="card shadow">
                
                <div class="card-header bg-transparent border-0">
                    <strong>Últimos Clientes Cadastrados</strong>
                </div>
                <div class="card-body">

                    <table class="table table-stripe">
                        <thead>
                            <tr>
                                <th scope="row">#</th>
                                <th>Nome Completo</th>
                                <th>Cadastrado em</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php if($clients): ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($client->id); ?></th>
                                        <td><?php echo e($client->name); ?></td>
                                        <td><?php echo e(date('d/m/Y - H:i', strtotime($client->created_at))); ?></td>
                                        <td>
                                            <a class="small" href="<?php echo e(route('users.index')); ?>"><i class="fa fa-eye small">Ver</i></a> &nbsp; | &nbsp;
                                            <a class="small" href="#"><i class="fa fa-pen small">Editar</i></a>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-end bg-transparent border-0">
                    <a href="">Ver todos
                        <a href="">Ver todos <i class="fa fa-arrow-right"></i> </a>
                    </a>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container-fluid py-5">
            <div class="row align-items-center text-center">
                <div class="col-12">
                    <h1>Bem-vindo à nossa loja virtual!</h1>
                    <p>Aqui você encontra os melhores produtos pelo melhor preço.</p>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary btn-lg">Ver produtos</a>
                </div>
            </div>
        </div>
    
    
    <?php endif; ?>

    <?php if(Auth::user()->is_admin): ?>    
    <div class="col-12 col-md-6">
        <div class="card shadow">
            <div class="card-header bg-transparent border-0">
                <strong>Últimos Produtos Cadastrados</strong>
            </div>
            <div class="card-body">

                <table class="table table-stripe">
                    <thead>
                        <tr>
                            <th scope="row">#</th>
                            <th>Produto</th>
                            <th>Qtd.</th>
                            <th>Status</th>
                            <th>Valor</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>Mouse Gamer</td>
                        <td>4</td>
                        <td><span class="badge bg-primary">venda</span></td>
                        <td><strong>R$90,00</strong></td>
                        <td>09/05/2023</td>
                      </tr>

                    </tbody>
                </table>

            </div>
            <div class="card-footer text-end bg-transparent border-0">
                <a href="">Ver todos
                    <a href="<?php echo e(route('products.index')); ?>">Ver todos <i class="fa fa-arrow-right"></i> </a>
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        document.querySelector('#order').addEventListener('change', function() {
            
           let text = document.querySelector('#order').value;
            
        if(text !== '' && text !== null) {
            document.querySelector('#img-code').setAttribute('src', `https://api.invertexto.com/v1/barcode?token=3544|zSqLDNTLu80u1S5v2UdEOSeMXTD8U3Tt&text=${text}&type=code39&font=arial`)
        }
    })

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views\erp\dashboard\index.blade.php ENDPATH**/ ?>