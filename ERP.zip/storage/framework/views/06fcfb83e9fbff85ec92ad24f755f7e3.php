<?php $__env->startSection('title', 'Carrinho de Compras'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row mt-4">
    <div class="col-12 col-md-12">
      <div class="card">
        <div class="card-header border-0 bg-transparent">
          <h4>Meu carrinho</h4>
        </div>
        <div class="card-body">
          <table class="table table-stripe">
            <thead>
              <tr>
                <th scope="row">#</th>
                <th>Cliente</th>
                <th>Valor</th>
                <th>Data/Hora</th>
            </tr>
            </thead>
            <tbody>
              <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($c['id']); ?></th>
                <td><?php echo e($c['name']); ?></td>
                <td><strong>R$450,00</strong></td>
                <td>20/2023 - 13:38</td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            
            </tbody>
            <tfoot>
              <tr>
                <td class="text-center" colspan="5">
                  <button class="btn btn-primary"> <i class="fa fa-check"></i> Solicitar</button>
                  <button type="reset" class="btn btn-secondary"> <i class="fa fa-times"></i> Cancelar</button>
                </td>
              </tr>
            </tfoot>
          </table>

        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aran\Desktop\ERP\resources\views\erp\cart\index.blade.php ENDPATH**/ ?>